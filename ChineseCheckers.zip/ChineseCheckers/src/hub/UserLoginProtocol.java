package hub;

import java.net.Socket;
import java.security.KeyStore;

import utils.Protocol;

public class UserLoginProtocol extends Protocol {

	@Override
	public void execute(Socket s, KeyStore ks) {
		// TODO Auto-generated method stub
		
	}

}
