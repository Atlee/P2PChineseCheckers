package peer;

import java.net.Socket;
import java.security.KeyStore;

import utils.Protocol;

public class UserLoginProtocol extends Protocol {

	@Override
	public void execute(Socket s, KeyStore keyStore) {
		// TODO Auto-generated method stub
		
	}

}
